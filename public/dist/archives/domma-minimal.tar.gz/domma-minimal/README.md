# Domma Minimal - v0.11.0

Core DOM manipulation and utilities

## What's Included

### JavaScript (~144KB)
- **Utils**: 120+ Lodash-compatible utilities
- **DOM**: jQuery-compatible DOM API (90+ methods)
- **Storage**: localStorage/sessionStorage wrapper
- **Icons**: SVG icon system (100+ icons)

### CSS (~53KB)
- **Domma Base CSS** (48KB): Base styles, typography, utilities
- **Grid System** (5KB): Bootstrap + CSS Grid utilities

## Quick Start

1. **Open index.html** in your browser
2. **Open the console** (F12) to see Domma loaded
3. **Start coding!**

## Using the Bundle

### Option 1: Individual CSS Files (Recommended for customization)
```html
<link rel="stylesheet" href="css/domma.css">
<link rel="stylesheet" href="css/grid.css">
<link rel="stylesheet" href="css/elements.css">
<link rel="stylesheet" href="css/domma-themes.css">
```

### Option 2: Bundled CSS (Recommended for simplicity)
```html
<link rel="stylesheet" href="css/domma-bundle.css">
```

### JavaScript
```html
<script src="dist/domma.min.js"></script>
```

## Examples

### DOM Manipulation
```javascript
$('button').on('click', function() {
    $(this).addClass('active');
});
```

### Utilities
```javascript
const users = [{name: 'Alice', age: 30}, {name: 'Bob', age: 25}];
const sorted = _.sortBy(users, 'age');
const grouped = _.groupBy(users, user => user.age > 27 ? 'senior' : 'junior');
```







## Use Case

Simple DOM manipulation, no UI components

## Documentation

- **Full API Docs**: https://domma.dev/docs
- **Showcase**: https://domma.dev/showcase
- **GitHub**: https://github.com/yourusername/domma

## License

Copyright © 2026 Darryl Waterhouse & DCBW-IT

---

Built with ❤️ using Domma 0.11.0
