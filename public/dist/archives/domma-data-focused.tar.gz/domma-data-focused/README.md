# Domma Data-Focused - v0.10.1

Data manipulation and tables

## What's Included

### JavaScript (~172KB)
- **Utils**: 120+ Lodash-compatible utilities
- **DOM**: jQuery-compatible DOM API (90+ methods)
- **Tables**: DataTable-like functionality
- **Icons**: SVG icon system (100+ icons)
- **Storage**: localStorage/sessionStorage wrapper
- **HTTP**: Fetch-based HTTP client

### CSS (~155KB)
- **Domma Base CSS** (48KB): Base styles, typography, utilities
- **Grid System** (5KB): Bootstrap + CSS Grid utilities
- **UI Components** (65KB): 19 UI components
- **Theme System** (37KB): Light/dark + colour variants
- **Grayve Theme** (5KB): Bootswatch Slate theme adaptation

## Quick Start

1. **Open index.html** in your browser
2. **Open the console** (F12) to see Domma loaded
3. **Start coding!**

## Using the Bundle

### Option 1: Individual CSS Files (Recommended for customization)
```html
<link rel="stylesheet" href="css/domma.css">
<link rel="stylesheet" href="css/grid.css">
<link rel="stylesheet" href="css/elements.css">
<link rel="stylesheet" href="css/domma-themes.css">
```

### Option 2: Bundled CSS (Recommended for simplicity)
```html
<link rel="stylesheet" href="css/domma-bundle.css">
```

### JavaScript
```html
<script src="dist/domma.min.js"></script>
```

## Examples

### DOM Manipulation
```javascript
$('button').on('click', function() {
    $(this).addClass('active');
});
```

### Utilities
```javascript
const users = [{name: 'Alice', age: 30}, {name: 'Bob', age: 25}];
const sorted = _.sortBy(users, 'age');
const grouped = _.groupBy(users, user => user.age > 27 ? 'senior' : 'junior');
```





### Data Tables
```javascript
const table = Domma.tables.create('#myTable', {
    data: users,
    columns: [
        {key: 'name', label: 'Name', sortable: true},
        {key: 'age', label: 'Age', sortable: true}
    ],
    pagination: true,
    pageSize: 10
});
```

## Use Case

Data-heavy applications, dashboards

## Documentation

- **Full API Docs**: https://domma.dev/docs
- **Showcase**: https://domma.dev/showcase
- **GitHub**: https://github.com/yourusername/domma

## License

Copyright © 2026 Darryl Waterhouse & DCBW-IT

---

Built with ❤️ using Domma 0.10.1
